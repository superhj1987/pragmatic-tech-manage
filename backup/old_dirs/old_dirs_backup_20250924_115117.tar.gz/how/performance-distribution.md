# 已迁移：请使用新目录下的文件

此文件内容已迁移至 `chapter2-how/performance-distribution.md`，为避免重复，旧文件保留为跳转说明。
